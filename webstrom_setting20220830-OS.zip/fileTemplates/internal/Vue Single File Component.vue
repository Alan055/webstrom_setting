<template>
  <div class="">

  </div>
</template>

<script >
	export default {
		data() {
			return {}
		},
		computed: {},
		watch: {},
		methods: {},
		created() {
		},
		mounted() {
		},
	}
</script>

<style lang='less' scoped>

</style>